package com.company.v2.operations;

public interface Operation {
    double perform(int[] numbers);
}
