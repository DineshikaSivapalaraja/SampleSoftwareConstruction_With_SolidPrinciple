package com.company.v2;

public class CommandLineOutput {
    public void show(String message){
         System.out.println(message);
    }
}
