package com.company.v3.operations;

public interface Operation {
    double perform(int[] numbers);
}
