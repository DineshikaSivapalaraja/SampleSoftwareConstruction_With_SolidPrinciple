package com.company.v4.operations;

public interface Operation {
    double perform(int[] numbers);
}
