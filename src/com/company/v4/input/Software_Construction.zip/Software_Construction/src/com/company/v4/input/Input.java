package com.company.v4.input;

public interface Input {
    String getOperator(String[] args); //todo: change this
}
