package com.company.v2;

public class CommandLineInput {

    public String getOperator(String[] args){ //todo: move args to constructor
        return args[0];
    }
}
