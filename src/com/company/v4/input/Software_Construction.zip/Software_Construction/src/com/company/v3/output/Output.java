package com.company.v3.output;

public interface Output {
    public void show(String message);
}
