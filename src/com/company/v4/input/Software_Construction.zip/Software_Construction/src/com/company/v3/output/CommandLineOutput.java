package com.company.v3.output;

public class CommandLineOutput implements Output {
    public void show(String message){

        System.out.println(message);
    }
}
