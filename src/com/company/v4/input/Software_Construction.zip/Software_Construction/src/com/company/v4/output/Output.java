package com.company.v4.output;

public interface Output {
    public void show(String message);
}
