package com.company.v3.input;

public interface Input {
    String getOperator(String[] arg); //todo: change this.

}
